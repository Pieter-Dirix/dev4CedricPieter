public interface Observer {
    void update();
}

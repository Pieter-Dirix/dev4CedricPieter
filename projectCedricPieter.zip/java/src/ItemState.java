public enum ItemState {
    IN_STOCK, OUT_OF_STOCK
}
